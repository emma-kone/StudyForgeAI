import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle, readJson } from "@/lib/api-helpers";

const hintSchema = z.object({ questionIdx: z.number().int().min(0) });

/** Fournit l'indice suivant d'une question (mode apprentissage). */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const user = await requireUser();
    const { id } = await ctx.params;
    const { questionIdx } = hintSchema.parse(await readJson<unknown>(req));
    const session = await db.session.findFirst({ where: { id, userId: user.id } });
    if (!session) throw new Error("Session introuvable.");
    const questions: Question[] = JSON.parse(session.questions);
    const hints = questions[questionIdx]?.hints ?? [];
    const used = session.hintsUsed;
    if (hints.length === 0) return { hint: null, message: "Aucun indice disponible pour cette question." };
    const idx = Math.min(used, hints.length - 1);
    await db.session.update({ where: { id }, data: { hintsUsed: used + 1 } });
    return { hint: hints[idx], remaining: hints.length - idx - 1 };
  });
}

type Question = import("@/lib/types").Question;
