import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle, readJson } from "@/lib/api-helpers";

const patchSchema = z.object({
  name: z.string().min(1).max(120).optional(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
});

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const user = await requireUser();
    const { id } = await ctx.params;
    const data = patchSchema.parse(await readJson<unknown>(req));
    const subject = await db.subject.findFirst({ where: { id, userId: user.id } });
    if (!subject) throw new Error("Matière introuvable.");
    return { subject: await db.subject.update({ where: { id }, data }) };
  });
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const user = await requireUser();
    const { id } = await ctx.params;
    const subject = await db.subject.findFirst({ where: { id, userId: user.id } });
    if (!subject) throw new Error("Matière introuvable.");
    await db.subject.delete({ where: { id } });
    return { ok: true };
  });
}
