import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle, readJson } from "@/lib/api-helpers";

const subjectSchema = z.object({
  name: z.string().min(1, "Nom requis").max(120),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/, "Couleur hex invalide").optional(),
  chapters: z.array(z.string().min(1).max(120)).max(30).optional(),
});

export async function GET() {
  return handle(async () => {
    const user = await requireUser();
    const subjects = await db.subject.findMany({
      where: { userId: user.id },
      include: {
        chapters: { orderBy: { position: "asc" } },
        _count: { select: { documents: true, exercises: true, sessions: true } },
      },
      orderBy: { createdAt: "asc" },
    });
    return { subjects };
  });
}

export async function POST(req: Request) {
  return handle(async () => {
    const user = await requireUser();
    const data = subjectSchema.parse(await readJson<unknown>(req));
    const subject = await db.subject.create({
      data: {
        userId: user.id,
        name: data.name,
        color: data.color ?? "#8b5cf6",
        chapters: data.chapters ? { create: data.chapters.map((name, i) => ({ name, position: i })) } : undefined,
      },
      include: { chapters: true },
    });
    return { subject };
  });
}
