import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle, readJson } from "@/lib/api-helpers";

const chapterSchema = z.object({
  subjectId: z.string().min(1),
  name: z.string().min(1, "Nom requis").max(120),
});

export async function POST(req: Request) {
  return handle(async () => {
    const user = await requireUser();
    const data = chapterSchema.parse(await readJson<unknown>(req));
    const subject = await db.subject.findFirst({ where: { id: data.subjectId, userId: user.id } });
    if (!subject) throw new Error("Matière introuvable.");
    const count = await db.chapter.count({ where: { subjectId: data.subjectId } });
    const chapter = await db.chapter.create({ data: { subjectId: data.subjectId, name: data.name, position: count } });
    return { chapter };
  });
}
