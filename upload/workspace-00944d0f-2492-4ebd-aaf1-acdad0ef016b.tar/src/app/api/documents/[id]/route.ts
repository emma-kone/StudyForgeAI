import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle, readJson } from "@/lib/api-helpers";

const patchSchema = z.object({
  name: z.string().min(1).max(120).optional(),
  subjectId: z.string().nullable().optional(),
  chapterId: z.string().nullable().optional(),
});

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const user = await requireUser();
    const { id } = await ctx.params;
    const doc = await db.document.findFirst({
      where: { id, userId: user.id },
      include: { chunks: { orderBy: { idx: "asc" }, take: 50 }, analyses: { take: 1 } },
    });
    if (!doc) throw new Error("Document introuvable.");
    return {
      document: {
        ...doc,
        analysis: doc.analyses[0] ?? null,
        chunks: doc.chunks.map((c) => ({ id: c.id, section: c.section, content: c.content.slice(0, 1200), words: c.words })),
      },
    };
  });
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const user = await requireUser();
    const { id } = await ctx.params;
    const data = patchSchema.parse(await readJson<unknown>(req));
    const doc = await db.document.findFirst({ where: { id, userId: user.id } });
    if (!doc) throw new Error("Document introuvable.");
    const updated = await db.document.update({ where: { id }, data });
    return { document: updated };
  });
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const user = await requireUser();
    const { id } = await ctx.params;
    const doc = await db.document.findFirst({ where: { id, userId: user.id } });
    if (!doc) throw new Error("Document introuvable.");
    await db.document.delete({ where: { id } });
    return { ok: true };
  });
}
