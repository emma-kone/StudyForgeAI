import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { extractContent } from "@/lib/extraction";

/** Réessaye l'extraction d'un document en échec. */
export async function POST(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const user = await requireUser();
    const { id } = await ctx.params;
    const doc = await db.document.findFirst({ where: { id, userId: user.id } });
    if (!doc) throw new Error("Document introuvable.");
    if (!doc.meta || !["pdf", "docx", "txt", "md", "pptx"].includes(doc.type)) {
      throw new Error("Format non pris en charge.");
    }
    await db.document.update({ where: { id }, data: { status: "PROCESSING", error: null } });
    try {
      // Le binaire original n'est pas conservé (politique de conservation) : extraction refaite impossible
      if (!doc.extractedText && doc.status !== "ERROR") throw new Error("Contenu source absent.");
      if (!doc.extractedText) throw new Error("Le contenu source n'est pas conservé après la première extraction ; réimportez le fichier.");
      const result = await extractContent(doc.type, Buffer.from(doc.extractedText, "utf8"));
      await db.document.update({
        where: { id },
        data: {
          status: "READY",
          extractedText: result.text,
          pageCount: result.pageCount ?? null,
          meta: JSON.stringify(result.meta),
        },
      });
      return { ok: true, status: "READY" };
    } catch (e) {
      const message = e instanceof Error ? e.message : "Échec de l'extraction.";
      await db.document.update({ where: { id }, data: { status: "ERROR", error: message } });
      throw new Error(message);
    }
  });
}
