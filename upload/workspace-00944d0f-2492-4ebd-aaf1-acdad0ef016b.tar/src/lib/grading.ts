import { db } from "@/lib/db";
import { ai } from "@/lib/ai";
import { runSqlScript, introspectSchema, dumpData } from "@/lib/sql-engine";
import { executeCode } from "@/lib/executor";
import type { CorrectionFeedback, CriterionScore, Question, RagPassage } from "@/lib/types";

// ─────────────────────────────────────────────────────────────────────────────
// Moteur de correction hybride
// 1. Règles déterministes pour tout ce qui est objectivement vérifiable
// 2. IA (grille d'évaluation) pour les réponses ouvertes
// Le calcul des points est effectué par cette logique applicative vérifiable.
// ─────────────────────────────────────────────────────────────────────────────

function norm(s: string): string {
  return (s ?? "")
    .toString()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[’']/g, "'")
    .replace(/[.,;:!?]+$/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function matchesAny(answer: string, accepted: string[]): boolean {
  const a = norm(answer);
  return accepted.some((acc) => {
    const variants = acc.split("|").map((v) => norm(v));
    return variants.some((v) => v === a || (v.length >= 4 && a.includes(v)) || (a.length >= 4 && v.includes(a)));
  });
}

function ok(points: number, max: number, explanation: string, extra?: Partial<CorrectionFeedback>): CorrectionFeedback {
  return { verdict: points >= max ? "correct" : "partial", points, explanation, ...extra };
}

function wrong(explanation: string, extra?: Partial<CorrectionFeedback>): CorrectionFeedback {
  return { verdict: "incorrect", points: 0, explanation, ...extra };
}

// ── Comparaison de résultats SQL ─────────────────────────────────────────────
function normalizeRows(rows: Record<string, unknown>[]): string[][] {
  return rows.map((r) =>
    Object.entries(r)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([k, v]) => `${k.toLowerCase()}=${v instanceof Date ? v.toISOString() : String(v)}`)
  );
}

function compareSqlResults(userRows: Record<string, unknown>[] | undefined, refRows: Record<string, unknown>[] | undefined): { equal: boolean; detail: string } {
  if (!userRows || !refRows) return { equal: false, detail: "Résultat indisponible." };
  const a = normalizeRows(userRows).sort().map((r) => r.join(" | "));
  const b = normalizeRows(refRows).sort().map((r) => r.join(" | "));
  if (a.length === b.length && a.every((row, i) => row === b[i])) {
    return { equal: true, detail: `Résultat identique (${a.length} ligne(s)).` };
  }
  const common = a.filter((row) => b.includes(row)).length;
  return {
    equal: false,
    detail: `Différence de résultat : ${a.length} ligne(s) obtenues vs ${b.length} attendues${common ? ` (${common} en commun)` : ""}.`,
  };
}

// ── Grille IA ────────────────────────────────────────────────────────────────
interface AiGrade {
  criteria: { criterion: string; awarded: number; max: number; comment?: string }[];
  total_awarded: number;
  explanation: string;
  uncertain?: boolean;
}

async function gradeWithAi(
  question: Question,
  userAnswer: string,
  passages: RagPassage[],
  userId: string
): Promise<CorrectionFeedback> {
  const max = question.points;
  const grid = [
    "Exactitude (réponse fidèle au cours)",
    "Respect des notions du cours",
    "Qualité du raisonnement",
    "Clarté et justification",
  ];
  const context = passages
    .slice(0, 6)
    .map((p) => `[${p.documentName}${p.section ? ` — ${p.section}` : ""}]\n${p.content.slice(0, 900)}`)
    .join("\n\n");

  const system =
    "Tu es un correcteur rigoureux et bienveillant pour des étudiants en informatique. " +
    "Tu évalues selon une grille fournie, en te basant PRIORITAIREMENT sur les extraits de cours fournis. " +
    "Tu ne justifies jamais une note sans critères. Réponds STRICTEMENT en JSON valide, sans texte autour.";
  const user = `Évalue la réponse de l'étudiant.

## Énoncé
${question.statement}
${question.instructions ? `\nConsignes : ${question.instructions}` : ""}

## Réponse attendue (référence du professeur)
${question.explanation || question.acceptedAnswers?.join(" ; ") || "Évalue la qualité académique et la cohérence avec le cours."}

## Extraits du cours de l'étudiant
${context || "(aucun extrait fourni — base-toi sur l'énoncé uniquement)"}

## Réponse de l'étudiant
${userAnswer.slice(0, 6000)}

## Barème total
${max} point(s)

## Grille
${grid.map((g, i) => `${i + 1}. ${g}`).join("\n")}

Réponds en JSON exactement :
{"criteria":[{"criterion":"...","awarded":0,"max":0,"comment":"..."}],"total_awarded":0,"explanation":"...","uncertain":false}
- total_awarded = somme des awarded (entre 0 et ${max}).
- explanation : 2 à 5 phrases pédagogiques citant le cours si pertinent.`;

  const res = await ai.completeJson<AiGrade>("grading", system, user, { userId, timeoutMs: 90_000 });
  if (!res.ok || !res.data) {
    return {
      verdict: "partial",
      points: 0,
      uncertain: true,
      explanation: `La correction automatique est momentanément indisponible (${res.error ?? "erreur IA"}). Votre réponse a été enregistrée : consultez la correction manuelle plus tard.`,
    };
  }
  const criteria: CriterionScore[] = (res.data.criteria ?? []).map((c) => ({
    criterion: c.criterion,
    awarded: Math.max(0, Math.min(Number(c.awarded) || 0, Number(c.max) || 0)),
    max: Number(c.max) || 0,
    comment: c.comment,
  }));
  const awarded = criteria.length
    ? Math.min(criteria.reduce((s, c) => s + c.awarded, 0), max)
    : Math.max(0, Math.min(Number(res.data.total_awarded) || 0, max));
  return {
    verdict: awarded >= max * 0.999 ? "correct" : awarded > 0 ? "partial" : "incorrect",
    points: Math.round(awarded * 100) / 100,
    criteria,
    explanation: res.data.explanation ?? "Évaluation par l'IA selon la grille.",
    uncertain: res.data.uncertain,
    sources: passages.slice(0, 3).map((p) => ({ document: p.documentName, section: p.section })),
  };
}

// ── Correction d'un exercice de code via tests + IA ──────────────────────────
async function gradeCodeQuestion(
  question: Question,
  userCode: string,
  passages: RagPassage[],
  userId: string
): Promise<CorrectionFeedback> {
  const tests = question.testCases ?? [];
  const language = question.language ?? "python";
  let passed = 0;
  const results: string[] = [];

  if (tests.length > 0) {
    for (const tc of tests) {
      const codeWithInput = tc.stdin
        ? `${userCode}\n\n# --- entrée du test ---\nimport sys, io as _io\nsys.stdin = _io.StringIO(${JSON.stringify(tc.stdin)})\n`
        : userCode;
      const run = await executeCode(language, codeWithInput);
      const output = (run.stdout || "").trim();
      if (!run.ok) {
        results.push(`✗ ${tc.name} : erreur d'exécution${run.timedOut ? " (délai dépassé)" : ""} — ${run.stderr.split("\n").slice(-3).join(" ")}`);
      } else if (output === tc.expected.trim()) {
        passed++;
        results.push(`✓ ${tc.name} : sortie conforme`);
      } else {
        results.push(`✗ ${tc.name} : sortie "${output.slice(0, 120)}" ≠ attendu "${tc.expected.slice(0, 120)}"`);
      }
    }
  }

  const testScore = tests.length ? (passed / tests.length) * question.points * 0.8 : null;

  // Revue IA qualitative (20 % + justification, ou tout le barème si pas de tests)
  const aiRes = await gradeWithAi(
    {
      ...question,
      points: tests.length ? question.points * 0.2 : question.points,
      statement: `${question.statement}\n\nCode soumis :\n\`\`\`\n${userCode.slice(0, 4000)}\n\`\`\`\n${results.join("\n")}`,
    },
    results.join("\n"),
    passages,
    userId
  );

  if (testScore !== null) {
    const points = Math.round((testScore + aiRes.points) * 100) / 100;
    return {
      verdict: passed === tests.length ? "correct" : points > 0 ? "partial" : "incorrect",
      points,
      criteria: aiRes.criteria,
      explanation: `${results.join("\n")}\n\n${aiRes.explanation}`,
      uncertain: aiRes.uncertain,
      expectedAnswer: question.solutionCode,
      sources: aiRes.sources,
    };
  }
  return aiRes;
}

// ── SQL ──────────────────────────────────────────────────────────────────────
function gradeSqlQuery(question: Question, userSql: string): CorrectionFeedback {
  if (!userSql.trim()) return wrong("Aucune requête soumise.");
  const userRun = runSqlScript(userSql, question.fixtureSql);
  const hasError = userRun.statements.some((s) => s.error);
  if (hasError) {
    const firstError = userRun.statements.find((s) => s.error)?.error;
    return wrong(`Erreur SQL : ${firstError}`);
  }
  if (!question.referenceSql) {
    // Pas de référence : validation structurelle basique
    return ok(question.points, question.points, "Requête exécutée sans erreur. Vérification par IA non disponible pour cette question.", { verdict: "correct" });
  }
  const refRun = runSqlScript(question.referenceSql, question.fixtureSql);
  const userSelect = userRun.statements.find((s) => s.kind === "select");
  const refSelect = refRun.statements.find((s) => s.kind === "select");
  const cmp = compareSqlResults(userSelect?.rows, refSelect?.rows);
  if (cmp.equal) {
    return ok(question.points, question.points, `Requête valide. ${cmp.detail} La solution différer textuellement est acceptée : c'est bien le résultat qui est évalué.`);
  }
  return wrong(`Requête exécutée sans erreur, mais ${cmp.detail}`, { expectedAnswer: question.referenceSql });
}

function gradeSqlCreateTable(question: Question, userSql: string): CorrectionFeedback {
  if (!userSql.trim()) return wrong("Aucune requête soumise.");
  const userSchema = introspectSchema(question.fixtureSql ?? "SELECT 1;", userSql);
  if (userSchema.error) return wrong(`Erreur SQL : ${userSchema.error}`);
  if (Object.keys(userSchema.tables).length === 0) return wrong("Aucune table créée.");

  const details: string[] = [];
  let totalCols = 0;
  let matchedCols = 0;
  if (question.referenceSql) {
    const refSchema = introspectSchema(question.fixtureSql ?? "SELECT 1;", question.referenceSql);
    for (const [table, refCols] of Object.entries(refSchema.tables)) {
      const userTable = userSchema.tables[table];
      if (!userTable) {
        details.push(`Table manquante : ${table}.`);
        totalCols += refCols.columns.length;
        continue;
      }
      for (const refCol of refCols.columns) {
        totalCols++;
        const found = userTable.columns.find((c) => c.name.toLowerCase() === refCol.name.toLowerCase());
        if (found) {
          matchedCols++;
          if (found.type.replace(/\(\d+\)/, "") !== refCol.type.replace(/\(\d+\)/, "")) {
            details.push(`${table}.${refCol.name} : type ${found.type} ≠ attendu ${refCol.type}.`);
          }
          if (refCol.pk && !found.pk) details.push(`${table}.${refCol.name} : clé primaire manquante.`);
        } else {
          details.push(`Colonne manquante : ${table}.${refCol.name}.`);
        }
      }
      for (const c of userTable.columns) {
        if (!refCols.columns.some((rc) => rc.name.toLowerCase() === c.name.toLowerCase())) {
          details.push(`Colonne supplémentaire : ${table}.${c.name} (acceptée).`);
        }
      }
    }
  } else {
    for (const [table, cols] of Object.entries(userSchema.tables)) details.push(`✓ ${table} (${cols.columns.length} colonnes)`);
    matchedCols = totalCols = 1;
  }
  const ratio = totalCols > 0 ? matchedCols / totalCols : 0;
  const points = Math.round(question.points * ratio * 100) / 100;
  if (ratio >= 0.999) {
    return ok(points, question.points, `Structure conforme : toutes les tables et colonnes attendues sont présentes.\n${details.join("\n")}`);
  }
  return {
    verdict: points > 0 ? "partial" : "incorrect",
    points,
    explanation: `Structure incomplète (${matchedCols}/${totalCols} éléments conformes).\n${details.join("\n")}`,
    expectedAnswer: question.referenceSql,
  };
}

function gradeSqlDatabase(question: Question, userSql: string): CorrectionFeedback {
  if (!userSql.trim()) return wrong("Aucun script soumis.");
  const run = runSqlScript(userSql, question.fixtureSql);
  const errors = run.statements.filter((s) => s.error);
  const executed = run.statements.filter((s) => !s.error);
  const dump = dumpData(question.fixtureSql ?? "SELECT 1;", userSql);
  const tableCount = Object.keys(dump.data).length;
  const explanation = [
    `${executed.length} instruction(s) exécutée(s) sans erreur, ${errors.length} en échec.`,
    `Tables présentes après exécution : ${tableCount}.`,
    ...errors.slice(0, 5).map((e) => `✗ ${e.sql.slice(0, 120)} → ${e.error}`),
  ].join("\n");
  if (errors.length === 0 && tableCount > 0) {
    return ok(question.points, question.points, explanation);
  }
  return {
    verdict: executed.length > 0 ? "partial" : "incorrect",
    points: Math.round((executed.length / Math.max(1, run.statements.length)) * question.points * 100) / 100,
    explanation,
    expectedAnswer: question.referenceSql,
  };
}

// ── Point d'entrée principal ─────────────────────────────────────────────────
export async function gradeAnswer(
  question: Question,
  userAnswer: unknown,
  passages: RagPassage[],
  userId: string
): Promise<CorrectionFeedback> {
  const max = question.points;
  const asString = typeof userAnswer === "string" ? userAnswer : JSON.stringify(userAnswer ?? "");

  switch (question.type) {
    case "qcm_single": {
      const picked = typeof userAnswer === "string" ? userAnswer : null;
      const correct = question.options?.find((o) => o.correct);
      if (!picked) return wrong("Aucune réponse sélectionnée.", { expectedAnswer: correct?.label });
      if (correct && picked === correct.id) return ok(max, max, question.explanation ?? "Bonne réponse !", { expectedAnswer: correct.label });
      const chosen = question.options?.find((o) => o.id === picked);
      return wrong(`Réponse incorrecte : « ${chosen?.label ?? "?"} ».
      ${question.explanation ?? ""}`, { expectedAnswer: correct?.label });
    }

    case "qcm_multiple": {
      const picked = Array.isArray(userAnswer) ? (userAnswer as string[]) : [];
      const correctIds = new Set((question.options ?? []).filter((o) => o.correct).map((o) => o.id));
      const correctPicked = picked.filter((p) => correctIds.has(p)).length;
      const wrongPicked = picked.filter((p) => !correctIds.has(p)).length;
      if (picked.length === 0) return wrong("Aucune réponse sélectionnée.");
      const score = Math.max(0, (correctPicked - wrongPicked) / correctIds.size) * max;
      return ok(Math.round(score * 100) / 100, max, `${correctPicked}/${correctIds.size} bonne(s) réponse(s) sélectionnée(s)${wrongPicked ? `, ${wrongPicked} erronée(s)` : ""}. ${question.explanation ?? ""}`);
    }

    case "true_false": {
      const picked = typeof userAnswer === "boolean" ? userAnswer : typeof userAnswer === "string" ? userAnswer === "true" : null;
      if (picked === null) return wrong("Aucune réponse sélectionnée.");
      const expected = question.options?.[0]?.correct ?? false;
      return picked === expected
        ? ok(max, max, question.explanation ?? "Exact !")
        : wrong(`Inexact. La réponse attendue est « ${expected ? "Vrai" : "Faux"} ». ${question.explanation ?? ""}`, { expectedAnswer: expected ? "Vrai" : "Faux" });
    }

    case "fill_blank": {
      const blanks = Array.isArray(userAnswer) ? (userAnswer as string[]) : [];
      const expected = question.blanks ?? [];
      if (expected.length === 0) return ok(max, max, question.explanation ?? "");
      let filled = 0;
      const detail: string[] = [];
      expected.forEach((acc, i) => {
        const variants = acc.split("|");
        if (blanks[i] != null && matchesAny(blanks[i], variants)) {
          filled++;
          detail.push(`✓ Trou ${i + 1}`);
        } else {
          detail.push(`✗ Trou ${i + 1} : attendu « ${variants[0]} »${blanks[i] ? `, obtenu « ${blanks[i]} »` : " (vide)"}`);
        }
      });
      const points = Math.round((filled / expected.length) * max * 100) / 100;
      return ok(points, max, `${filled}/${expected.length} trou(s) correct(s).\n${detail.join("\n")}\n${question.explanation ?? ""}`);
    }

    case "short_answer": {
      if (!asString.trim()) return wrong("Réponse vide.");
      const accepted = question.acceptedAnswers ?? [];
      if (accepted.length && matchesAny(asString, accepted)) return ok(max, max, question.explanation ?? "Exact !");
      // Pas de correspondance déterministe → l'IA apprécie la réponse
      const aiRes = await gradeWithAi(question, asString, passages, userId);
      return aiRes;
    }

    case "matching": {
      const pairs = question.pairs ?? [];
      const answer = (typeof userAnswer === "object" && userAnswer !== null ? userAnswer : {}) as Record<string, string>;
      if (!pairs.length) return ok(max, max, question.explanation ?? "");
      let good = 0;
      for (const p of pairs) {
        if (answer[p.left] && norm(answer[p.left]) === norm(p.right)) good++;
      }
      const points = Math.round((good / pairs.length) * max * 100) / 100;
      const detail = pairs.map((p) => `${answer[p.left] && norm(answer[p.left]) === norm(p.right) ? "✓" : "✗"} ${p.left} → ${p.right}`).join("\n");
      return ok(points, max, `${good}/${pairs.length} association(s) correcte(s).\n${detail}`);
    }

    case "ordering": {
      const expected = question.orderedItems ?? [];
      const answer = Array.isArray(userAnswer) ? (userAnswer as string[]) : [];
      if (!expected.length) return ok(max, max, question.explanation ?? "");
      let inPlace = 0;
      expected.forEach((item, i) => {
        if (answer[i] && norm(answer[i]) === norm(item)) inPlace++;
      });
      // Crédit partiel basé sur la plus longue sous-séquence commune (ordre relatif)
      const normExpected = expected.map(norm);
      const normAnswer = answer.map(norm);
      let lis = 0;
      for (const item of normExpected) {
        if (normAnswer.includes(item)) lis++;
      }
      const points = Math.round(Math.max(inPlace / expected.length, (lis / expected.length) * 0.7) * max * 100) / 100;
      return ok(
        points,
        max,
        `Ordre correct pour ${inPlace}/${expected.length} éléments.\nSéquence attendue :\n${expected.map((e, i) => `${i + 1}. ${e}`).join("\n")}`
      );
    }

    case "error_identification": {
      const answer = (typeof userAnswer === "object" && userAnswer !== null ? userAnswer : {}) as { line?: number; explanation?: string };
      const expectedLine = question.errorLine;
      const lineOk = expectedLine != null && Number(answer.line) === expectedLine;
      const explanationOk = answer.explanation && question.explanation && norm(answer.explanation).split(/\s+/).filter(Boolean).length >= 3;
      const pts = (lineOk ? max * 0.5 : 0) + (explanationOk ? max * 0.5 : 0);
      return ok(
        Math.round(pts * 100) / 100,
        max,
        `${lineOk ? "✓ Ligne correcte identifiée" : `✗ Ligne attendue : ${expectedLine}`}${explanationOk ? "\n✓ Explication pertinente" : ""}\n${question.explanation ?? ""}`
      );
    }

    case "code_output": {
      if (!asString.trim()) return wrong("Réponse vide.");
      const expected = question.expectedOutput ?? "";
      const normalizedUser = asString.trim().split("\n").map((l) => l.trim()).join("\n");
      const normalizedExpected = expected.trim().split("\n").map((l) => l.trim()).join("\n");
      return normalizedUser === normalizedExpected
        ? ok(max, max, question.explanation ?? "Sortie exacte !")
        : wrong(`Sortie attendue :\n${normalizedExpected}\n\nVotre réponse :\n${normalizedUser.slice(0, 300)}`, { expectedAnswer: normalizedExpected });
    }

    case "code_write":
    case "code_fix":
    case "debug":
      return gradeCodeQuestion(question, asString, passages, userId);

    case "sql_query":
      return gradeSqlQuery(question, asString);

    case "sql_create_table":
      return gradeSqlCreateTable(question, asString);

    case "sql_database":
      return gradeSqlDatabase(question, asString);

    case "open_question":
    case "case_study":
    case "data_modeling":
    case "combined":
    case "exam_composite":
    default: {
      if (!asString.trim() || asString.trim().length < 5) {
        return wrong("Réponse vide ou trop courte pour être évaluée.");
      }
      return gradeWithAi(question, asString, passages, userId);
    }
  }
}

/** Met à jour les statistiques de notions après une session corrigée. */
export async function updateConceptStats(userId: string, question: Question, feedback: CorrectionFeedback) {
  for (const notion of question.notions?.length ? question.notions : ["Général"]) {
    const existing = await db.conceptStat.findUnique({ where: { userId_notion: { userId, notion } } });
    const attempts = (existing?.attempts ?? 0) + 1;
    const correct = (existing?.correct ?? 0) + (feedback.verdict === "correct" ? 1 : 0);
    const partial = (existing?.partial ?? 0) + (feedback.verdict === "partial" ? 1 : 0);
    // Maîtrise : EMA pondérée — une seule réussite ne suffit pas
    const verdictScore = feedback.verdict === "correct" ? 1 : feedback.verdict === "partial" ? 0.5 : 0;
    const prev = existing?.mastery ?? 0.3;
    const mastery = Math.max(0, Math.min(1, prev * 0.6 + verdictScore * 0.4));
    await db.conceptStat.upsert({
      where: { userId_notion: { userId, notion } },
      create: { userId, notion, attempts: 1, correct: feedback.verdict === "correct" ? 1 : 0, partial: feedback.verdict === "partial" ? 1 : 0, mastery },
      update: { attempts, correct, partial, mastery, lastSeen: new Date() },
    });
  }
}
