import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { AuthError, rateLimit } from "@/lib/auth";

export function jsonError(message: string, status = 400, extra?: Record<string, unknown>) {
  return NextResponse.json({ error: message, ...extra }, { status });
}

/** Enveloppe standard : auth → validation → logique, erreurs centralisées. */
export async function handle<T>(fn: () => Promise<T>): Promise<NextResponse> {
  try {
    const data = await fn();
    return NextResponse.json(data ?? { ok: true });
  } catch (err) {
    if (err instanceof AuthError) return jsonError("Authentification requise.", 401);
    if (err instanceof ZodError) {
      return jsonError("Données invalides : " + err.issues.map((i) => `${i.path.join(".")} — ${i.message}`).join("; "), 422);
    }
    const message = err instanceof Error ? err.message : "Erreur interne";
    console.error("[API]", message);
    return jsonError(message, 500);
  }
}

export function limit(key: string, max: number, windowMs: number) {
  if (!rateLimit(key, max, windowMs)) {
    throw new Error("Trop de requêtes — patientez un instant avant de réessayer.");
  }
}

export async function readJson<T>(req: Request): Promise<T> {
  try {
    return (await req.json()) as T;
  } catch {
    throw new Error("Corps de requête JSON invalide.");
  }
}
