"use client";

import { create } from "zustand";

export type View = "dashboard" | "library" | "generate" | "session" | "code" | "sql" | "progress" | "settings";

export interface AppUser {
  id: string;
  email: string;
  name: string | null;
}

interface AppState {
  authenticated: boolean | null; // null = vérification en cours
  user: AppUser | null;
  view: View;
  activeSessionId: string | null;
  setAuthenticated: (ok: boolean, user?: AppUser | null) => void;
  setView: (view: View) => void;
  openSession: (sessionId: string) => void;
  closeSession: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  authenticated: null,
  user: null,
  view: "dashboard",
  activeSessionId: null,
  setAuthenticated: (ok, user = null) => set({ authenticated: ok, user }),
  setView: (view) => set({ view }),
  openSession: (sessionId) => set({ view: "session", activeSessionId: sessionId }),
  closeSession: () => set({ view: "dashboard", activeSessionId: null }),
}));
