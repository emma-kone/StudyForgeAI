"use client";

// ─────────────────────────────────────────────────────────────────────────────
// LibraryView — Bibliothèque de documents de StudyForge AI.
// - Import multi-fichiers (PDF, DOCX, PPTX, TXT, MD) avec matière/chapitre
//   optionnels, résultats détaillés par fichier
// - Création de matières et de chapitres en ligne
// - Filtres serveur : recherche plein texte, statut, matière
// - Cartes documents : statut, métadonnées, analyse IA, réessai, suppression
// - Dialogue de détails : informations, renommage, déplacement, analyse IA,
//   extraits indexés
// ─────────────────────────────────────────────────────────────────────────────

import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "@/lib/client-api";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import {
  CheckCircle2,
  FileCode,
  FileText,
  FileType,
  Loader2,
  Presentation,
  RotateCw,
  Search,
  Sparkles,
  Trash2,
  Upload,
  XCircle,
} from "lucide-react";

// ── Types de l'API ───────────────────────────────────────────────────────────

type DocStatus = "PENDING" | "PROCESSING" | "READY" | "ERROR";

interface ApiChapter {
  id: string;
  name: string;
  position: number;
}

interface ApiSubject {
  id: string;
  name: string;
  color: string;
  chapters: ApiChapter[];
  _count: { documents: number; exercises: number; sessions: number };
}

interface SubjectsResponse {
  subjects: ApiSubject[];
}

interface ApiDocument {
  id: string;
  name: string;
  originalName: string;
  type: string;
  size: number;
  status: DocStatus;
  pageCount: number | null;
  error: string | null;
  createdAt: string;
  subject: { name: string; color: string } | null;
  chapter: { name: string } | null;
  _count: { chunks: number };
}

interface DocumentsResponse {
  documents: ApiDocument[];
}

interface UploadResultItem {
  name: string;
  ok: boolean;
  id?: string;
  error?: string;
  warnings?: string[];
}

interface UploadResponse {
  ok: boolean;
  results: UploadResultItem[];
}

interface DocumentAnalysis {
  summary: string | null;
  subjectGuess: string | null;
  chapters: string | null;
  notions: string | null;
  definitions: string | null;
  methods: string | null;
  formulas: string | null;
  codeExcerpts: string | null;
  pitfalls: string | null;
  prerequisites: string | null;
  model: string | null;
}

interface ApiChunk {
  id: string;
  section: string | null;
  content: string;
  words: number;
}

interface ApiDocumentDetail extends ApiDocument {
  extractedText: string | null;
  analysis: DocumentAnalysis | null;
  chunks: ApiChunk[];
}

interface DocumentDetailResponse {
  document: ApiDocumentDetail;
}

// ── Constantes et utilitaires ────────────────────────────────────────────────

/** Sentinelle pour les Select Radix (value="" est interdit) ↔ état local "". */
const NONE = "none";
/** Sentinelle du filtre de statut « tous ». */
const ALL = "all";

const ACCEPTED_EXTENSIONS = ".pdf,.docx,.txt,.md,.pptx";

type AnalysisListKey =
  | "notions"
  | "definitions"
  | "methods"
  | "formulas"
  | "pitfalls"
  | "prerequisites";

const ANALYSIS_LISTS: { key: AnalysisListKey; label: string }[] = [
  { key: "notions", label: "Notions clés" },
  { key: "definitions", label: "Définitions" },
  { key: "methods", label: "Méthodes" },
  { key: "formulas", label: "Formules" },
  { key: "pitfalls", label: "Pièges à éviter" },
  { key: "prerequisites", label: "Prérequis" },
];

const dateFormatter = new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeStyle: "short" });

function formatDate(iso: string): string {
  const date = new Date(iso);
  return Number.isNaN(date.getTime()) ? "—" : dateFormatter.format(date);
}

function formatSize(size: number): string {
  return size < 1024 * 1024 ? `${Math.round(size / 1024)} Ko` : `${(size / 1024 / 1024).toFixed(1)} Mo`;
}

/** Analyse défensive d'un champ d'analyse encodé en JSON (tableau de chaînes). */
function parseStringArray(raw: string | null): string[] {
  if (!raw) return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.map((item) => String(item).trim()).filter((item) => item.length > 0);
  } catch {
    const trimmed = raw.trim();
    return trimmed.length > 0 ? [trimmed] : [];
  }
}

/** Icône par type de fichier (table de correspondance statique). */
const DOC_TYPE_ICONS: Record<string, typeof FileText> = {
  pdf: FileText,
  docx: FileText,
  pptx: Presentation,
  md: FileCode,
};

function statusMeta(status: DocStatus): {
  label: string;
  variant: "default" | "destructive" | "secondary" | "outline";
} {
  switch (status) {
    case "READY":
      return { label: "Prêt", variant: "default" };
    case "ERROR":
      return { label: "Erreur", variant: "destructive" };
    case "PROCESSING":
      return { label: "Traitement…", variant: "secondary" };
    default:
      return { label: "En attente", variant: "outline" };
  }
}

function errorMessage(err: unknown, fallback: string): string {
  return err instanceof Error && err.message ? err.message : fallback;
}

// ── Ligne d'information (dl/dt/dd) ───────────────────────────────────────────

function InfoRow({
  label,
  value,
  tnum = false,
  mono = false,
}: {
  label: string;
  value: string;
  tnum?: boolean;
  mono?: boolean;
}) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-border/60 pb-1.5">
      <dt className="typo-meta shrink-0">{label}</dt>
      <dd className={cn("min-w-0 truncate text-right text-sm font-medium", tnum && "tnum", mono && "font-code")}>
        {value}
      </dd>
    </div>
  );
}

// ── Carte document ───────────────────────────────────────────────────────────

interface DocumentCardProps {
  doc: ApiDocument;
  analyzing: boolean;
  retrying: boolean;
  onAnalyze: (id: string) => void;
  onRetry: (id: string) => void;
  onOpen: (id: string) => void;
  onDelete: (doc: ApiDocument) => void;
}

function DocumentCard({
  doc,
  analyzing,
  retrying,
  onAnalyze,
  onRetry,
  onOpen,
  onDelete,
}: DocumentCardProps) {
  const Icon = DOC_TYPE_ICONS[doc.type.toLowerCase()] ?? FileType;
  const status = statusMeta(doc.status);

  return (
    <Card className="flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-start gap-2.5">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground">
            <Icon className="h-4 w-4" aria-hidden />
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate font-medium" title={doc.originalName}>
              {doc.name}
            </p>
            <Badge variant={status.variant} className="mt-1">
              {status.label}
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex flex-1 flex-col gap-1.5 pt-0">
        <p className="typo-meta tnum">
          {doc.type.toUpperCase()} · {formatSize(doc.size)}
          {doc.pageCount ? ` · ${doc.pageCount} p.` : ""}
        </p>
        <p className="typo-meta tnum">Importé le {formatDate(doc.createdAt)}</p>
        {doc.subject && (
          <p className="typo-meta flex items-center gap-1.5">
            <span
              className="h-2 w-2 shrink-0 rounded-full"
              style={{ backgroundColor: doc.subject.color }}
              aria-hidden
            />
            <span className="truncate">
              {doc.subject.name}
              {doc.chapter ? ` · ${doc.chapter.name}` : ""}
            </span>
          </p>
        )}
        <p className="typo-meta tnum">{doc._count.chunks} extrait(s) indexé(s)</p>

        {doc.status === "ERROR" && doc.error && (
          <p className="typo-meta line-clamp-2 text-destructive">{doc.error}</p>
        )}
        {doc.status === "ERROR" && (
          <div className="pt-1">
            <Button size="sm" variant="outline" onClick={() => onRetry(doc.id)} disabled={retrying}>
              {retrying ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                <RotateCw className="h-4 w-4" aria-hidden />
              )}
              Réessayer
            </Button>
          </div>
        )}

        <div className="mt-auto flex flex-wrap items-center gap-1.5 pt-3">
          {doc.status === "READY" && (
            <Button size="sm" variant="outline" onClick={() => onAnalyze(doc.id)} disabled={analyzing}>
              {analyzing ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                <Sparkles className="h-4 w-4" aria-hidden />
              )}
              {analyzing ? "Analyse…" : "Analyser (IA)"}
            </Button>
          )}
          <Button size="sm" variant="ghost" onClick={() => onOpen(doc.id)}>
            Détails
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="ml-auto size-8 text-muted-foreground hover:text-destructive"
            aria-label="Supprimer"
            onClick={() => onDelete(doc)}
          >
            <Trash2 className="h-4 w-4" aria-hidden />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// ── Vue principale ───────────────────────────────────────────────────────────

export default function LibraryView() {
  const { toast } = useToast();

  // ── Données ──
  const [subjects, setSubjects] = useState<ApiSubject[] | null>(null);
  const [subjectsError, setSubjectsError] = useState<string | null>(null);
  const [docs, setDocs] = useState<ApiDocument[] | null>(null);
  const [docsLoading, setDocsLoading] = useState(true);
  const [docsError, setDocsError] = useState<string | null>(null);

  // ── Filtres (refetch serveur) ──
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState(ALL);
  const [subjectFilter, setSubjectFilter] = useState("");

  // ── Import ──
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [uploading, setUploading] = useState(false);
  const [importResults, setImportResults] = useState<UploadResultItem[] | null>(null);
  const [importSubjectId, setImportSubjectId] = useState("");
  const [importChapterId, setImportChapterId] = useState("");

  // ── Création matière / chapitre ──
  const [newSubjectName, setNewSubjectName] = useState("");
  const [creatingSubject, setCreatingSubject] = useState(false);
  const [newChapterName, setNewChapterName] = useState("");
  const [creatingChapter, setCreatingChapter] = useState(false);

  // ── Actions par document ──
  const [analyzingId, setAnalyzingId] = useState<string | null>(null);
  const [retryingId, setRetryingId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ApiDocument | null>(null);
  const [deleting, setDeleting] = useState(false);

  // ── Détails (dialogue) ──
  const [detailsId, setDetailsId] = useState<string | null>(null);
  const [details, setDetails] = useState<ApiDocumentDetail | null>(null);
  const [detailsLoading, setDetailsLoading] = useState(false);
  const [detailsError, setDetailsError] = useState<string | null>(null);
  const [renameName, setRenameName] = useState("");
  const [savingRename, setSavingRename] = useState(false);
  const [moveSubjectId, setMoveSubjectId] = useState("");
  const [moveChapterId, setMoveChapterId] = useState("");
  const [savingMove, setSavingMove] = useState(false);

  /** Référence synchrone des matières pour préremplir le dialogue de détails. */
  const subjectsRef = useRef<ApiSubject[]>([]);

  // ── Chargement des matières ──
  const loadSubjects = useCallback(async () => {
    try {
      const res = await api.get<SubjectsResponse>("/api/subjects");
      setSubjects(res.subjects);
      subjectsRef.current = res.subjects;
      setSubjectsError(null);
    } catch (err: unknown) {
      setSubjectsError(errorMessage(err, "Impossible de charger les matières."));
    }
  }, []);

  // ── Chargement des documents (filtres serveur) ──
  const loadDocs = useCallback(async () => {
    setDocsLoading(true);
    setDocsError(null);
    try {
      const params = new URLSearchParams();
      const trimmedSearch = search.trim();
      if (trimmedSearch) params.set("q", trimmedSearch);
      if (statusFilter !== ALL) params.set("status", statusFilter);
      if (subjectFilter) params.set("subjectId", subjectFilter);
      const query = params.toString();
      const res = await api.get<DocumentsResponse>(`/api/documents${query ? `?${query}` : ""}`);
      setDocs(res.documents);
    } catch (err: unknown) {
      setDocsError(errorMessage(err, "Impossible de charger les documents."));
    } finally {
      setDocsLoading(false);
    }
  }, [search, statusFilter, subjectFilter]);

  // Chargement initial des matières
  useEffect(() => {
    void loadSubjects();
  }, [loadSubjects]);

  // Debounce de la recherche (300 ms)
  useEffect(() => {
    const timer = setTimeout(() => setSearch(searchInput), 300);
    return () => clearTimeout(timer);
  }, [searchInput]);

  // Rechargement des documents à chaque changement de filtre
  useEffect(() => {
    void loadDocs();
  }, [loadDocs]);

  // ── Dérivés ──
  const selectedImportSubject = subjects?.find((s) => s.id === importSubjectId) ?? null;
  const importChapters = [...(selectedImportSubject?.chapters ?? [])].sort(
    (a, b) => a.position - b.position,
  );
  const moveSubject = subjects?.find((s) => s.id === moveSubjectId) ?? null;
  const moveChapters = [...(moveSubject?.chapters ?? [])].sort((a, b) => a.position - b.position);
  const filtersActive = search.trim() !== "" || statusFilter !== ALL || subjectFilter !== "";

  // ── Import de fichiers ──
  const handleUpload = useCallback(
    async (fileList: FileList | null) => {
      if (!fileList || fileList.length === 0 || uploading) return;
      setUploading(true);
      setImportResults(null);
      const formData = new FormData();
      for (const file of Array.from(fileList)) formData.append("files", file);
      if (importSubjectId) formData.append("subjectId", importSubjectId);
      if (importChapterId) formData.append("chapterId", importChapterId);
      try {
        const res = await api.post<UploadResponse>("/api/documents", formData);
        setImportResults(res.results);
        const okCount = res.results.filter((r) => r.ok).length;
        const failCount = res.results.length - okCount;
        if (failCount === 0) {
          toast({
            title: "Import terminé",
            description: `${okCount} document(s) importé(s) avec succès.`,
          });
        } else if (okCount === 0) {
          toast({
            title: "Import impossible",
            description: "Aucun fichier n'a pu être importé.",
            variant: "destructive",
          });
        } else {
          toast({
            title: "Import partiel",
            description: `${okCount} fichier(s) importé(s), ${failCount} en échec.`,
          });
        }
        await Promise.all([loadDocs(), loadSubjects()]);
      } catch (err: unknown) {
        toast({
          title: "Erreur d'import",
          description: errorMessage(err, "L'import des documents a échoué."),
          variant: "destructive",
        });
      } finally {
        setUploading(false);
        if (fileInputRef.current) fileInputRef.current.value = "";
      }
    },
    [uploading, importSubjectId, importChapterId, loadDocs, loadSubjects, toast],
  );

  // ── Création de matière / chapitre ──
  const handleCreateSubject = useCallback(async () => {
    const name = newSubjectName.trim();
    if (!name || creatingSubject) return;
    setCreatingSubject(true);
    try {
      await api.post<{ subject: ApiSubject }>("/api/subjects", { name });
      toast({ title: "Matière créée", description: `« ${name} » est désormais disponible.` });
      setNewSubjectName("");
      await loadSubjects();
    } catch (err: unknown) {
      toast({
        title: "Création impossible",
        description: errorMessage(err, "La création de la matière a échoué."),
        variant: "destructive",
      });
    } finally {
      setCreatingSubject(false);
    }
  }, [newSubjectName, creatingSubject, loadSubjects, toast]);

  const handleCreateChapter = useCallback(async () => {
    const name = newChapterName.trim();
    if (!name || !importSubjectId || creatingChapter) return;
    setCreatingChapter(true);
    try {
      await api.post<{ chapter: ApiChapter }>("/api/chapters", {
        subjectId: importSubjectId,
        name,
      });
      toast({
        title: "Chapitre ajouté",
        description: `« ${name} » a été ajouté à « ${selectedImportSubject?.name ?? "la matière"} ».`,
      });
      setNewChapterName("");
      await loadSubjects();
    } catch (err: unknown) {
      toast({
        title: "Ajout impossible",
        description: errorMessage(err, "L'ajout du chapitre a échoué."),
        variant: "destructive",
      });
    } finally {
      setCreatingChapter(false);
    }
  }, [newChapterName, importSubjectId, creatingChapter, selectedImportSubject, loadSubjects, toast]);

  // ── Détails : ouverture / fermeture / chargement ──
  const refreshDetails = useCallback(async () => {
    if (!detailsId) return;
    try {
      const res = await api.get<DocumentDetailResponse>(`/api/documents/${detailsId}`);
      setDetails(res.document);
    } catch {
      // Rafraîchissement silencieux : le dialogue conserve l'état affiché.
    }
  }, [detailsId]);

  const closeDetails = useCallback(() => {
    setDetailsId(null);
    setDetails(null);
    setDetailsError(null);
  }, []);

  useEffect(() => {
    if (!detailsId) return;
    let cancelled = false;
    setDetailsLoading(true);
    setDetailsError(null);
    api
      .get<DocumentDetailResponse>(`/api/documents/${detailsId}`)
      .then((res) => {
        if (cancelled) return;
        setDetails(res.document);
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        setDetailsError(errorMessage(err, "Impossible de charger les détails du document."));
      })
      .finally(() => {
        if (!cancelled) setDetailsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [detailsId]);

  // Préremplissage du renommage et du déplacement à la réception des détails
  useEffect(() => {
    if (!details) return;
    setRenameName(details.name);
    const subject = details.subject
      ? subjectsRef.current.find((s) => s.name === details.subject?.name)
      : undefined;
    const subjectId = subject?.id ?? "";
    setMoveSubjectId(subjectId);
    const chapter =
      subject && details.chapter
        ? subject.chapters.find((c) => c.name === details.chapter?.name)
        : undefined;
    setMoveChapterId(chapter?.id ?? "");
  }, [details]);

  // ── Analyse IA ──
  const analyzeDocument = useCallback(
    async (docId: string) => {
      if (analyzingId) return;
      setAnalyzingId(docId);
      try {
        await api.post<{ ok: boolean }>(`/api/documents/${docId}/analyze`);
        toast({ title: "Analyse terminée", description: "Le document a été analysé par l'IA." });
        if (detailsId === docId) await refreshDetails();
        await loadDocs();
      } catch (err: unknown) {
        toast({
          title: "Analyse impossible",
          description: errorMessage(err, "L'analyse IA a échoué."),
          variant: "destructive",
        });
      } finally {
        setAnalyzingId(null);
      }
    },
    [analyzingId, detailsId, refreshDetails, loadDocs, toast],
  );

  // ── Retraitement après erreur ──
  const retryDocument = useCallback(
    async (docId: string) => {
      if (retryingId) return;
      setRetryingId(docId);
      try {
        await api.post<{ ok: boolean }>(`/api/documents/${docId}/retry`);
        toast({ title: "Traitement relancé", description: "Le document va être retraité." });
        await loadDocs();
      } catch (err: unknown) {
        toast({
          title: "Nouvel essai impossible",
          description: errorMessage(err, "Le retraitement du document a échoué."),
          variant: "destructive",
        });
      } finally {
        setRetryingId(null);
      }
    },
    [retryingId, loadDocs, toast],
  );

  // ── Suppression ──
  const confirmDelete = useCallback(async () => {
    const target = deleteTarget;
    if (!target || deleting) return;
    setDeleting(true);
    try {
      await api.del<{ ok: boolean }>(`/api/documents/${target.id}`);
      toast({ title: "Document supprimé", description: `« ${target.name} » a été supprimé.` });
      setDeleteTarget(null);
      if (detailsId === target.id) closeDetails();
      await Promise.all([loadDocs(), loadSubjects()]);
    } catch (err: unknown) {
      toast({
        title: "Suppression impossible",
        description: errorMessage(err, "La suppression du document a échoué."),
        variant: "destructive",
      });
    } finally {
      setDeleting(false);
    }
  }, [deleteTarget, deleting, detailsId, closeDetails, loadDocs, loadSubjects, toast]);

  // ── Renommage / déplacement (dialogue) ──
  const handleRename = useCallback(async () => {
    if (!details || savingRename) return;
    const name = renameName.trim();
    if (!name || name === details.name) return;
    setSavingRename(true);
    try {
      await api.patch<{ document: ApiDocument }>(`/api/documents/${details.id}`, { name });
      toast({ title: "Document renommé", description: `Le document s'appelle désormais « ${name} ».` });
      await Promise.all([loadDocs(), refreshDetails()]);
    } catch (err: unknown) {
      toast({
        title: "Renommage impossible",
        description: errorMessage(err, "Le renommage a échoué."),
        variant: "destructive",
      });
    } finally {
      setSavingRename(false);
    }
  }, [details, savingRename, renameName, loadDocs, refreshDetails, toast]);

  const handleMove = useCallback(async () => {
    if (!details || savingMove) return;
    setSavingMove(true);
    try {
      await api.patch<{ document: ApiDocument }>(`/api/documents/${details.id}`, {
        subjectId: moveSubjectId || null,
        chapterId: moveChapterId || null,
      });
      toast({
        title: "Document déplacé",
        description: "L'affectation matière / chapitre a été mise à jour.",
      });
      await Promise.all([loadDocs(), loadSubjects(), refreshDetails()]);
    } catch (err: unknown) {
      toast({
        title: "Déplacement impossible",
        description: errorMessage(err, "Le déplacement a échoué."),
        variant: "destructive",
      });
    } finally {
      setSavingMove(false);
    }
  }, [details, savingMove, moveSubjectId, moveChapterId, loadDocs, loadSubjects, refreshDetails, toast]);

  function resetFilters() {
    setSearchInput("");
    setSearch("");
    setStatusFilter(ALL);
    setSubjectFilter("");
  }

  const analyzingInDialog = analyzingId !== null && details !== null && analyzingId === details.id;

  // ── Rendu ──
  return (
    <section
      aria-labelledby="library-title"
      className="mx-auto w-full max-w-6xl space-y-6 px-4 py-6 sm:px-6 lg:py-8"
    >
      {/* ── En-tête ── */}
      <header>
        <h1 id="library-title" className="typo-h1">
          Bibliothèque
        </h1>
        <p className="typo-subtitle mt-1 max-w-2xl">
          Importez vos cours (PDF, DOCX, PPTX, TXT, MD) et organisez-les par matière et chapitre.
        </p>
      </header>

      {docsError && (
        <Alert variant="destructive">
          <XCircle aria-hidden />
          <AlertTitle>Chargement impossible</AlertTitle>
          <AlertDescription className="flex flex-wrap items-center gap-3">
            {docsError}
            <Button size="sm" variant="outline" onClick={() => void loadDocs()}>
              Réessayer
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* ── Import et organisation ── */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="typo-h2">Import et organisation</CardTitle>
          <CardDescription>
            Les fichiers importés sont découpés et indexés automatiquement pour la génération
            d&apos;exercices.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Ligne 1 : import + affectation optionnelle */}
          <div className="flex flex-col gap-3 xl:flex-row xl:items-center">
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept={ACCEPTED_EXTENSIONS}
              className="hidden"
              onChange={(e) => void handleUpload(e.target.files)}
            />
            <Button onClick={() => fileInputRef.current?.click()} disabled={uploading}>
              {uploading ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                <Upload className="h-4 w-4" aria-hidden />
              )}
              {uploading ? "Import en cours…" : "Importer des documents"}
            </Button>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center xl:ml-auto">
              <Select
                value={importSubjectId === "" ? undefined : importSubjectId}
                onValueChange={(value) => {
                  setImportSubjectId(value === NONE ? "" : value);
                  setImportChapterId("");
                }}
              >
                <SelectTrigger className="w-full sm:w-52" aria-label="Matière des documents importés">
                  <SelectValue placeholder="Matière (optionnel)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={NONE}>Aucune matière</SelectItem>
                  {(subjects ?? []).map((subject) => (
                    <SelectItem key={subject.id} value={subject.id}>
                      {subject.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select
                value={importChapterId === "" ? undefined : importChapterId}
                onValueChange={(value) => setImportChapterId(value === NONE ? "" : value)}
                disabled={!importSubjectId}
              >
                <SelectTrigger className="w-full sm:w-52" aria-label="Chapitre des documents importés">
                  <SelectValue placeholder="Chapitre (optionnel)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={NONE}>Aucun chapitre</SelectItem>
                  {importChapters.map((chapter) => (
                    <SelectItem key={chapter.id} value={chapter.id}>
                      {chapter.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Résultats du dernier import */}
          {importResults && importResults.length > 0 && (
            <div className="rounded-lg border bg-muted/40 p-3">
              <p className="typo-meta mb-2 font-medium">Résultat du dernier import</p>
              <ul className="space-y-1.5">
                {importResults.map((result, index) => (
                  <li key={`${result.name}-${index}`} className="flex items-start gap-2 text-sm">
                    {result.ok ? (
                      <CheckCircle2
                        className="mt-0.5 h-4 w-4 shrink-0 text-green-600 dark:text-green-500"
                        aria-hidden
                      />
                    ) : (
                      <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" aria-hidden />
                    )}
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-medium">{result.name}</span>
                      {result.error && (
                        <span className="typo-meta block text-destructive">{result.error}</span>
                      )}
                      {result.ok && result.warnings && result.warnings.length > 0 && (
                        <span className="typo-meta block">{result.warnings.join(" · ")}</span>
                      )}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Ligne 2 : création de matière / chapitre */}
          <div className="border-t pt-4">
            <p className="typo-h3 mb-3">Nouvelle matière</p>
            <div className="flex flex-col gap-3 md:flex-row md:items-end">
              <div className="w-full space-y-1.5 md:max-w-xs">
                <Label htmlFor="new-subject-name">Nom de la matière</Label>
                <Input
                  id="new-subject-name"
                  placeholder="Ex. : Algorithmique"
                  value={newSubjectName}
                  onChange={(e) => setNewSubjectName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") void handleCreateSubject();
                  }}
                  disabled={creatingSubject}
                />
              </div>
              <Button
                onClick={() => void handleCreateSubject()}
                disabled={creatingSubject || newSubjectName.trim() === ""}
              >
                {creatingSubject && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
                Créer la matière
              </Button>
              {selectedImportSubject && (
                <>
                  <div className="w-full space-y-1.5 md:max-w-xs">
                    <Label htmlFor="new-chapter-name">
                      Nouveau chapitre — {selectedImportSubject.name}
                    </Label>
                    <Input
                      id="new-chapter-name"
                      placeholder="Ex. : Chapitre 1 — Complexité"
                      value={newChapterName}
                      onChange={(e) => setNewChapterName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") void handleCreateChapter();
                      }}
                      disabled={creatingChapter}
                    />
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => void handleCreateChapter()}
                    disabled={creatingChapter || newChapterName.trim() === ""}
                  >
                    {creatingChapter && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
                    Ajouter le chapitre
                  </Button>
                </>
              )}
            </div>
            {subjectsError && (
              <p className="typo-meta mt-2 text-destructive">{subjectsError}</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* ── Filtres ── */}
      <div className="flex flex-col gap-3 md:flex-row md:items-center">
        <div className="relative w-full md:max-w-xs">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <Input
            type="search"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Rechercher un document…"
            className="pl-9"
            aria-label="Rechercher un document"
          />
        </div>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center md:ml-auto">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-40" aria-label="Filtrer par statut">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Tous</SelectItem>
              <SelectItem value="READY">Prêt</SelectItem>
              <SelectItem value="ERROR">Erreur</SelectItem>
            </SelectContent>
          </Select>
          <Select
            value={subjectFilter === "" ? undefined : subjectFilter}
            onValueChange={(value) => setSubjectFilter(value === NONE ? "" : value)}
          >
            <SelectTrigger className="w-full sm:w-48" aria-label="Filtrer par matière">
              <SelectValue placeholder="Toutes les matières" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={NONE}>Toutes les matières</SelectItem>
              {(subjects ?? []).map((subject) => (
                <SelectItem key={subject.id} value={subject.id}>
                  {subject.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* ── Grille des documents ── */}
      {docs === null && docsLoading && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3" aria-hidden>
          {Array.from({ length: 6 }).map((_, index) => (
            <Card key={index}>
              <CardHeader className="pb-3">
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-4 w-1/3" />
              </CardHeader>
              <CardContent className="space-y-2">
                <Skeleton className="h-3 w-full" />
                <Skeleton className="h-3 w-2/3" />
                <Skeleton className="h-8 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {docs !== null && docs.length > 0 && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {docs.map((doc) => (
            <DocumentCard
              key={doc.id}
              doc={doc}
              analyzing={analyzingId === doc.id}
              retrying={retryingId === doc.id}
              onAnalyze={(id) => void analyzeDocument(id)}
              onRetry={(id) => void retryDocument(id)}
              onOpen={setDetailsId}
              onDelete={setDeleteTarget}
            />
          ))}
        </div>
      )}

      {docs !== null && docs.length === 0 && !docsLoading && (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed py-12 text-center">
          {filtersActive ? (
            <>
              <Search className="h-8 w-8 text-muted-foreground" aria-hidden />
              <p className="typo-subtitle">Aucun document ne correspond aux filtres.</p>
              <Button variant="outline" onClick={resetFilters}>
                Réinitialiser les filtres
              </Button>
            </>
          ) : (
            <>
              <Upload className="h-8 w-8 text-muted-foreground" aria-hidden />
              <h2 className="typo-h3">Aucun document</h2>
              <p className="typo-subtitle">Importez votre premier cours pour commencer.</p>
            </>
          )}
        </div>
      )}

      {/* ── Dialogue de détails ── */}
      <Dialog
        open={detailsId !== null}
        onOpenChange={(open) => {
          if (!open) closeDetails();
        }}
      >
        <DialogContent className="max-h-[80vh] max-w-2xl overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="typo-h3 pr-6">
              {details?.name ?? "Détails du document"}
            </DialogTitle>
            <DialogDescription>
              {details ? details.originalName : "Chargement des informations…"}
            </DialogDescription>
          </DialogHeader>

          {detailsLoading && (
            <div className="space-y-4" aria-hidden>
              <Skeleton className="h-4 w-1/2" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-4 w-2/3" />
              <Skeleton className="h-32 w-full" />
            </div>
          )}

          {detailsError && !detailsLoading && (
            <Alert variant="destructive">
              <XCircle aria-hidden />
              <AlertTitle>Chargement impossible</AlertTitle>
              <AlertDescription>{detailsError}</AlertDescription>
            </Alert>
          )}

          {details && !detailsLoading && (
            <div className="space-y-6">
              {/* Informations */}
              <section className="space-y-2" aria-label="Informations">
                <h3 className="typo-h2">Informations</h3>
                <dl className="space-y-1.5">
                  <InfoRow label="Fichier d'origine" value={details.originalName} />
                  <InfoRow label="Type" value={details.type.toUpperCase()} />
                  <InfoRow
                    label="Taille"
                    value={`${formatSize(details.size)}${details.pageCount ? ` · ${details.pageCount} p.` : ""}`}
                    tnum
                  />
                  <InfoRow label="Statut" value={statusMeta(details.status).label} />
                  <InfoRow label="Importé le" value={formatDate(details.createdAt)} />
                  <InfoRow label="Matière" value={details.subject?.name ?? "—"} />
                  <InfoRow label="Chapitre" value={details.chapter?.name ?? "—"} />
                </dl>
              </section>

              {/* Renommer / Déplacer */}
              <section className="space-y-3" aria-label="Renommer ou déplacer">
                <h3 className="typo-h2">Renommer / Déplacer</h3>
                <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
                  <div className="flex-1 space-y-1.5">
                    <Label htmlFor="doc-rename">Nom du document</Label>
                    <Input
                      id="doc-rename"
                      value={renameName}
                      onChange={(e) => setRenameName(e.target.value)}
                      disabled={savingRename}
                    />
                  </div>
                  <Button
                    size="sm"
                    onClick={() => void handleRename()}
                    disabled={
                      savingRename ||
                      renameName.trim() === "" ||
                      renameName.trim() === details.name
                    }
                  >
                    {savingRename && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
                    Enregistrer
                  </Button>
                </div>
                <Separator />
                <div className="grid gap-2 sm:grid-cols-2">
                  <Select
                    value={moveSubjectId === "" ? undefined : moveSubjectId}
                    onValueChange={(value) => {
                      setMoveSubjectId(value === NONE ? "" : value);
                      setMoveChapterId("");
                    }}
                  >
                    <SelectTrigger aria-label="Matière du document">
                      <SelectValue placeholder="Aucune matière" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={NONE}>Aucune matière</SelectItem>
                      {(subjects ?? []).map((subject) => (
                        <SelectItem key={subject.id} value={subject.id}>
                          {subject.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select
                    value={moveChapterId === "" ? undefined : moveChapterId}
                    onValueChange={(value) => setMoveChapterId(value === NONE ? "" : value)}
                    disabled={!moveSubjectId}
                  >
                    <SelectTrigger aria-label="Chapitre du document">
                      <SelectValue placeholder="Aucun chapitre" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={NONE}>Aucun chapitre</SelectItem>
                      {moveChapters.map((chapter) => (
                        <SelectItem key={chapter.id} value={chapter.id}>
                          {chapter.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button size="sm" variant="outline" onClick={() => void handleMove()} disabled={savingMove}>
                  {savingMove && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
                  Enregistrer
                </Button>
              </section>

              {/* Analyse IA */}
              <section className="space-y-3" aria-label="Analyse IA">
                <h3 className="typo-h2">Analyse IA</h3>
                {details.analysis ? (
                  <div className="space-y-4">
                    {details.analysis.summary && (
                      <p className="typo-subtitle whitespace-pre-wrap">{details.analysis.summary}</p>
                    )}
                    {(details.analysis.subjectGuess || details.analysis.model) && (
                      <div className="flex flex-wrap items-center gap-2">
                        {details.analysis.subjectGuess && (
                          <Badge variant="secondary">
                            Matière suggérée : {details.analysis.subjectGuess}
                          </Badge>
                        )}
                        {details.analysis.model && <Badge variant="outline">{details.analysis.model}</Badge>}
                      </div>
                    )}
                    {ANALYSIS_LISTS.map(({ key, label }) => {
                      const items = parseStringArray(details.analysis?.[key] ?? null);
                      if (items.length === 0) return null;
                      return (
                        <div key={key} className="space-y-1.5">
                          <h4 className="typo-h3">{label}</h4>
                          <ul className="max-h-40 list-disc space-y-1 overflow-y-auto pl-5 text-sm">
                            {items.map((item, index) => (
                              <li key={index}>{item}</li>
                            ))}
                          </ul>
                        </div>
                      );
                    })}
                    {parseStringArray(details.analysis.codeExcerpts).length > 0 && (
                      <div className="space-y-2">
                        <h4 className="typo-h3">Extraits de code</h4>
                        {parseStringArray(details.analysis.codeExcerpts).map((code, index) => (
                          <pre
                            key={index}
                            className="font-code overflow-x-auto rounded-lg bg-muted p-3 text-xs leading-relaxed"
                          >
                            {code}
                          </pre>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-start gap-3">
                    <p className="typo-meta">Ce document n&apos;a pas encore été analysé.</p>
                    <Button
                      size="sm"
                      onClick={() => details && void analyzeDocument(details.id)}
                      disabled={analyzingInDialog}
                    >
                      {analyzingInDialog ? (
                        <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                      ) : (
                        <Sparkles className="h-4 w-4" aria-hidden />
                      )}
                      {analyzingInDialog ? "Analyse en cours…" : "Analyser (IA)"}
                    </Button>
                  </div>
                )}
              </section>

              {/* Extraits indexés */}
              <section className="space-y-2" aria-label="Extraits indexés">
                <h3 className="typo-h2">Extraits indexés</h3>
                {details.chunks.length === 0 ? (
                  <p className="typo-meta">Aucun extrait indexé pour ce document.</p>
                ) : (
                  <ul className="max-h-96 space-y-2 overflow-y-auto pr-1">
                    {details.chunks.slice(0, 10).map((chunk) => (
                      <li key={chunk.id} className="rounded-lg border p-3">
                        <Badge variant="outline" className="mb-1.5">
                          {chunk.section || "Sans titre"}
                        </Badge>
                        <p className="line-clamp-6 whitespace-pre-wrap text-sm">{chunk.content}</p>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ── Confirmation de suppression ── */}
      <AlertDialog
        open={deleteTarget !== null}
        onOpenChange={(open) => {
          if (!open) setDeleteTarget(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer ce document ?</AlertDialogTitle>
            <AlertDialogDescription>
              « {deleteTarget?.name ?? "Ce document"} » sera définitivement supprimé, ainsi que ses
              extraits indexés et son analyse IA. Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Annuler</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void confirmDelete();
              }}
              disabled={deleting}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleting ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                <Trash2 className="h-4 w-4" aria-hidden />
              )}
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
