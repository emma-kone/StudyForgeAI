# Task 2-b — StudyForge AI : LibraryView + SettingsView

## Travail réalisé

Deux fichiers créés (aucun autre fichier modifié, dev server non lancé, lint global non exécuté) :

1. `src/components/studyforge/LibraryView.tsx` (1276 lignes)
   - En-tête `h1` « Bibliothèque » (`typo-h1`, id `library-title`, `aria-labelledby`).
   - Carte « Import et organisation » : input fichier caché (`.pdf,.docx,.txt,.md,.pptx`, multiple), bouton « Importer des documents » (Loader2 + « Import en cours… » pendant l'upload), Select matière (« Matière (optionnel) ») + Select chapitre lié à la matière (désactivé sans matière), résultats par fichier inline (CheckCircle2 text-green-600 / XCircle text-destructive + erreur/avertissements) + toast récapitulatif, refresh documents + matières.
   - Ligne 2 `border-t pt-4` « Nouvelle matière » : POST `/api/subjects` ; chapitre POST `/api/chapters` affiché uniquement quand une matière est sélectionnée.
   - Filtres (refetch serveur via `GET /api/documents?q=&status=&subjectId=`) : recherche debouncée 300 ms, statut (Tous / Prêt / Erreur), matière.
   - Grille `grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4` : carte par document (icône par type via table statique `DOC_TYPE_ICONS`, badge statut READY/ERROR/PROCESSING/PENDING, méta `type · taille · pages` (tnum), date fr-FR, pastille matière + chapitre, `extrait(s) indexé(s)`, erreur + « Réessayer » (POST retry), « Analyser (IA) » (READY uniquement, POST analyze), « Détails » (Dialog), Trash2 + AlertDialog de confirmation (DELETE).
   - Dialog détails (`max-w-2xl`, `max-h-[80vh] overflow-y-auto`, fetch au montage, skeleton) : Informations (dl), Renommer/Déplacer (PATCH name + PATCH subjectId/chapterId avec sentinelles `none` → null), Analyse IA (summary, subjectGuess, 6 listes parsées défensivement via `parseStringArray`, extraits de code en `<pre className="font-code text-xs">`, bouton « Analyser (IA) » si analysis null), Extraits indexés (10 premiers, `max-h-96 overflow-y-auto`).
   - États vides : aucun document (icône Upload + typo-h3 + typo-subtitle) / filtres sans résultat (« Réinitialiser les filtres »). Erreurs de chargement en Alert destructive. Toasts sur toutes les mutations.

2. `src/components/studyforge/SettingsView.tsx` (570 lignes)
   - `h1` « Réglages » + typo-subtitle.
   - Apparence (Palette) : thème système/clair/sombre → PUT `{ theme }` ; application manuelle de la classe `dark` sur `<html>` (aucun ThemeProvider) au montage après fetch + à chaque changement + écoute `prefers-color-scheme` quand « système ».
   - Exercices (PenLine) : mode par défaut (5 modes mappés, valeur serveur inconnue ajoutée défensivement) → PUT `{ defaultMode }` ; Switch « Indices disponibles pendant les sessions » → PUT `{ hintsEnabled }`.
   - Import (Upload) : Input number min 1 max 50, bouton « Enregistrer » actif seulement si modifié → PUT `{ maxUploadMB }`, note typo-meta.
   - Compte (User) : e-mail / nom (« — » si null) / identifiant (typo-meta font-code tronqué) + lecture seule : modèle IA, langue (fr → « Français »), conservation (0 → « Illimitée », sinon « N jours »).
   - Charte typographique (Type) : spécimens Bricolage Grotesque 200/400/500/600/700/800 (classes littérales `font-extralight` → `font-extrabold text-lg`, libellés typo-meta « Bricolage Grotesque — N »), séparateur, spécimen `font-code text-sm` JetBrains Mono, intro typo-meta (placée dans CardContent car `text-sm` de CardDescription écraserait `.typo-meta` en layer utilities).
   - Chaque changement : état local optimiste + PUT + toast « Réglages enregistrés » ; en cas d'erreur → toast destructive + revert.

## Points techniques notables

- Sentinelle `NONE = "none"` pour les Select Radix (`value=""` interdit) convertie en `""`/`null` à l'interface API.
- `react-hooks/static-components` (activé malgré la désactivation de react-compiler) : `docTypeIcon()` retournait un composant créé au rendu → remplacé par la table statique `DOC_TYPE_ICONS` (accès membre, conforme comme dans AppShell).
- Aucune déclaration de font-family, aucun `font-[...]` : uniquement `typo-*`, `font-code`, `tnum` de globals.css.
- Vérifications : `bunx eslint` scoped → 0 erreur 0 warning ; `bunx tsc --noEmit` → aucune erreur sur ces deux fichiers (erreurs préexistantes hors périmètre dans `src/lib/executor.ts`, non touchées).

## Notes pour les agents suivants

- `GET /api/subjects` et `/api/documents` doivent exister côté serveur (tâches backend) avec les contraintes ci-dessus ; la vue affiche un Alert si indisponible.
- Le thème est appliqué manuellement dans SettingsView : ne pas ajouter de ThemeProvider global (risque de double application).
- `/agent-ctx` a été créé à la racine du projet (`/home/z/my-project/agent-ctx`) faute de droits sur `/`.
