# Task 2-c — GenerateView.tsx (StudyForge AI)

## Résultat
- Fichier créé : `src/components/studyforge/GenerateView.tsx` (815 lignes) — un seul fichier, aucun autre modifié.
- Vérification : `bunx eslint src/components/studyforge/GenerateView.tsx` → **0 erreur, 0 warning** (exit 0).
- `bunx tsc --noEmit` filtré sur « GenerateView » → **aucune erreur TS** dans ce fichier.

## Conformité au contrat
- Props exactes : `interface GenerateViewProps { onSessionCreated: (sessionId: string) => void }`, default export, `"use client"` en tête.
- Racine : `<section className="space-y-6" aria-labelledby="generate-title">` + `<h1 id="generate-title" className="typo-h1">Générer des exercices</h1>` + typo-subtitle. Un seul h1, pas de footer/sidebar.
- Layout desktop : grille `lg:grid-cols-3` — Card formulaire `lg:col-span-2` + colonne latérale (Card « Exercices précédents »).
- Données : `Promise.all` sur GET `/api/subjects`, `/api/documents`, `/api/exercises/list` au montage (compteur `refresh` pour retry) ; erreurs → Alert destructive + bouton « Réessayer » ; chargement → Skeletons.
- Documents : seuls `status === "READY"` ; filtre matière via Select (sentinelle `"all"`) ; liste max-h-56 overflow-y-auto ; Badge compteur « N sélectionné(s) » (tnum) + « Tout sélectionner » / « Effacer » (ghost sm) ; badge matière avec pastille colorée (dot inline style) ; si aucun doc prêt → Alert + « Aller à la Bibliothèque » (`useAppStore.setView("library")`).
- Notions : Input + Entrée → themes[] (max 10, doublons ignorés, toast si limite), Badges supprimables (X avec aria-label), typo-meta d'aide.
- Difficulté (5 options, « Moyen (défaut) » par défaut sélectionné) + nombre de questions (1–20, défaut 5) en grille 2 colonnes.
- Types (requis) : 5 presets outline sm (QCM & Vrai/Faux, Code, SQL, Réflexion, Tout=20) qui remplacent la sélection ; grille checkboxes max-h-64 sm:grid-cols-2 avec QUESTION_TYPE_LABELS ; Badge « N type(s) ».
- Mode de session (5 modes MODE_LABELS, défaut apprentissage) ; champ « Durée (minutes) » 1–240 optionnel si mode === "examen".
- Points par question (1–20, défaut 1) + Correction (Immédiate / À la fin de la session).
- Slider théorie/pratique 0–100 step 5 + meta `Théorie X % · Pratique Y %` (tnum) ; Switch « Autoriser les indices » (défaut true).
- Soumission : désactivée si 0 document ou 0 type (helper typo-meta « Sélectionnez au moins un document » / « Choisissez au moins un type d’exercice ») ; POST `/api/exercises` puis POST `/api/sessions` → toast « Exercices générés » + `onSessionCreated(sessionId)` ; pendant génération : bouton « Génération en cours… (IA, 30 à 90 s) » + Alert pleine largeur avec Loader2 animé ; erreurs → toast destructive avec err.message.
- Historique : liste max-h-[32rem] overflow-y-auto (titre tronqué + title attr, « N question(s) · date » via Intl.DateTimeFormat("fr-FR", { dateStyle: "medium" }), pastille matière, Badge difficulté, bouton « Démarrer » (Play) avec loading par ligne → POST `/api/sessions` { exerciseId, mode: config.mode ?? "apprentissage" }) ; état vide icône + typo-h3 + typo-subtitle.

## Points techniques
- Typographie : uniquement les classes partagées (typo-h1/h3/subtitle/meta, tnum) — aucune font-family ni classe arbitraire de police.
- Apostrophes typographiques (’) dans le texte JSX → compatible react/no-unescaped-entities.
- TS strict, aucun `any` ; DTO locaux typés (SubjectDto, DocumentDto, HistoryExerciseDto, ConfigState) ; `clampInt` pour les inputs number ; effect sans dépendance manquante (deps `[refresh]`).
- Composants shadcn/ui utilisés : button, card, badge, input, label, select, checkbox, slider, skeleton, alert, separator, switch. Icônes lucide : BookOpen, FileX, History, Loader2, Play, Sparkles, TriangleAlert, X.
