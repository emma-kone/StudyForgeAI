# Task 2-a — StudyForge AI : DashboardView + ProgressView

## Fichiers créés (exclusivement ces deux fichiers — aucun autre fichier modifié)

| Fichier | Lignes | Rôle |
|---|---|---|
| `src/components/studyforge/DashboardView.tsx` | 569 | Vue "Tableau de bord" (default export, sans props) |
| `src/components/studyforge/ProgressView.tsx` | 611 | Vue "Progression" (default export, props `onGenerateRevision(exerciseId, sessionId)`) |

## Vérifications effectuées

- `bunx eslint src/components/studyforge/DashboardView.tsx src/components/studyforge/ProgressView.tsx` → **0 erreur, 0 warning** (sortie vide).
- `bunx tsc --noEmit` (vérification lecture seule) → **aucune erreur TypeScript** dans ces deux fichiers (mode strict).
- Contrats API confirmés par lecture du backend existant :
  - `GET /api/stats` → forme `Stats` complète (counts, overallAvg, bySubject, timeline, workMinutes, conceptStats, recommendations, recentSessions, ai, examResults).
  - `GET /api/recommendations` → `{ recommendations, conceptStats }` ; `PATCH /api/recommendations` `{ id, status }` (status `OPEN`/`ACCEPTED`/`DISMISSED`).
  - `POST /api/exercises/revision` `{ notion, difficulty }` → `{ ok, exerciseId, questionCount }` (difficulty = `decouverte|facile|moyen|difficile|expert`, défaut `moyen` — aligné sur `zod` du backend et `Difficulty` de `@/lib/types`).
  - `POST /api/sessions` `{ exerciseId, mode }` → `{ ok, sessionId }`.
- AppShell consomme bien : `<DashboardView />` et `<ProgressView onGenerateRevision={(exerciseId, sessionId) => openSession(sessionId)} />`.

## Points d'implémentation

- Typographie globale uniquement : `typo-h1/h2/h3/subtitle/meta`, `tnum` sur les valeurs numériques, aucune déclaration de font-family, pas de classes arbitraires de police. `font-code` non pertinent ici.
- Dashboard : accueil si 0 matières + 0 documents + 0 sessions (CTA → Bibliothèque) ; 4 KPI (grid-cols-2 lg:grid-cols-4) + carte "Temps de travail cumulé" ; recommandations (badge priorité, bouton "Voir la progression" dans le header, ligne cliquable → progress) ; sessions récentes cliquables → `openSession(id)` avec pastille couleur matière, badge mode (map locale MODE_LABELS) et badge statut (En cours/Soumise/pourcentage coloré) ; répartition par matière (barres div avec couleur inline) ; concepts top 6 (Progress + tentatives) ; alerte IA conditionnelle.
- Progression : 3 cartes de synthèse ; "Évolution des notes" (max-h-72, plus récent en tête, barres div h-2.5 bg-primary) ; "Maîtrise par notion" triée asc avec badges "À revoir" (3 plus faibles ou mastery<0.4) / "Acquis" (≥0.75) et état vide ; "Révisions ciblées" avec Select de difficulté partagé, flux génération en 2 POST séquentiels + toast + `onGenerateRevision`, bouton "Ignorer" (PATCH DISMISSED + refresh via compteur) ; "Résultats d'examens" ; bouton "Nouvel exercice" → `setView("generate")`.
- Chargement = Skeletons, erreurs = Alert destructive avec bouton Réessayer, listes longues = `max-h-96 overflow-y-auto` (max-h-72 pour la timeline), dates via `Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeStyle: "short" })`.
- A11y : un seul `h1` par vue avec `id` + `aria-labelledby` sur la `<section>` racine, icônes décoratives `aria-hidden`, labels sur les Progress/Select.
- Aucune nouvelle dépendance, URLs `/api` relatives uniquement, pas d'emojis, pas de footer/sidebar dans les vues.
